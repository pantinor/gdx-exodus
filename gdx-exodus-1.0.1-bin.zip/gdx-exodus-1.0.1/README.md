gdx-exodus
=========

An AMAZING port of Ultima III Exodus using LIBGDX, with a few updates...

* Sosaria is 256x256 instead of 64x64
* One of the wizard light/torch spells is swapped out with a different more useful spell.
* A few more monsters

This is a maven project..and it runs as it should, on a PEESEE.

To journey onward, download the zip file, extract, and run the "java -jar command" and have fun!

![screenshot of the example](https://raw.github.com/pantinor/gdx-exodus/master/shot1.png)

![screenshot of the example](https://raw.github.com/pantinor/gdx-exodus/master/shot2.png)

![screenshot of the example](https://raw.github.com/pantinor/gdx-exodus/master/shot3.png)

![screenshot of the example](https://raw.github.com/pantinor/gdx-exodus/master/shot4.png)

